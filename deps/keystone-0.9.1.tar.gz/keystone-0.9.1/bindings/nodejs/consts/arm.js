// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [arm_const.js]
module.exports.ERR_ASM_ARM_INVALIDOPERAND = 512
module.exports.ERR_ASM_ARM_MISSINGFEATURE = 513
module.exports.ERR_ASM_ARM_MNEMONICFAIL = 514
